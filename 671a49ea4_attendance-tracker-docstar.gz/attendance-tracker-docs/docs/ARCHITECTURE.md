# Architecture

## High-Level Flow

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│  Frontend    │────▶│  Backend API  │────▶│  Database    │
│  (React)     │◀────│  (Express)    │◀────│  (Postgres)  │
└─────────────┘     └──────────────┘     └─────────────┘
       │                                           │
       │            ┌──────────────┐               │
       └───────────▶│ Master Report │◀──────────────┘
                    │ Aggregation   │
                    └──────────────┘
```

## Key Principles

1. **School isolation** — Each school's roster and attendance data is scoped. School managers only see their assigned school(s).
2. **Single source of truth** — Attendance is stored per employee per day. The master report is a real-time aggregation, not a stored snapshot.
3. **No time tracking** — This is presence/absence marking only. No hours, no clock-in/out times.
4. **Day-by-day marking** — Managers select a date and mark each employee's status for that day.

## Frontend Architecture

### Pages

| Page             | Route                    | Description |
|------------------|--------------------------|-------------|
| Dashboard        | `/`                      | Overview of all 15 schools with quick stats |
| School View      | `/schools/:id`           | Roster + attendance grid for a specific school |
| Master Report    | `/reports/master`        | Aggregated attendance across all schools with date filters |

### Components

- **SchoolSelector** — Dropdown/tab list of 15 schools
- **AttendanceGrid** — Calendar grid: employees (rows) × dates (columns), click to cycle status
- **StatusBadge** — Color-coded status indicator
- **ReportTable** — Aggregated stats table for master report

## Backend Architecture

### REST API

RESTful endpoints grouped by resource:
- `/api/schools` — CRUD for schools
- `/api/employees` — CRUD for employees (scoped to school)
- `/api/attendance` — GET/POST attendance records
- `/api/reports/master` — Aggregated report data (computed on demand)

### Master Report Aggregation

The master report endpoint queries attendance across all schools for a date range and returns:

```
Per school:
  - Total employees
  - Days marked
  - Present count / rate
  - Absent count / rate
  - Late count / rate
  - Excused count / rate
  - Remote count / rate

Overall:
  - Same metrics aggregated across all 15 schools
```

## Authentication

- JWT-based auth with role claims
- Middleware checks role + school assignment
- Super Admin bypasses school scoping
- School Manager is filtered to assigned school IDs

## Database Schema

See [DATA_MODEL.md](./DATA_MODEL.md) for full schema details.
