# Data Model

## Entity Relationship

```
schools 1───∞ employees 1───∞ attendance_records
```

---

## Table: schools

| Column        | Type         | Constraints    | Description |
|---------------|--------------|----------------|-------------|
| id            | UUID         | PK, auto-gen   | |
| name          | VARCHAR(255) | NOT NULL       | School name |
| location      | VARCHAR(255) |                | City/state |
| code          | VARCHAR(20)  | UNIQUE         | Short code (e.g., "RIV") |
| created_at    | TIMESTAMP    | DEFAULT NOW()  | |
| updated_at    | TIMESTAMP    | DEFAULT NOW()  | |

---

## Table: employees

| Column        | Type         | Constraints         | Description |
|---------------|--------------|----------------------|-------------|
| id            | UUID         | PK, auto-gen         | |
| school_id     | UUID         | FK → schools.id      | Which school they belong to |
| first_name    | VARCHAR(100) | NOT NULL             | |
| last_name     | VARCHAR(100) | NOT NULL             | |
| role          | VARCHAR(100) |                      | e.g., "Teacher", "Admin", "Custodian" |
| email         | VARCHAR(255) |                      | |
| is_active     | BOOLEAN      | DEFAULT TRUE         | Soft-delete flag |
| created_at    | TIMESTAMP    | DEFAULT NOW()        | |
| updated_at    | TIMESTAMP    | DEFAULT NOW()        | |

---

## Table: attendance_records

| Column        | Type         | Constraints              | Description |
|---------------|--------------|--------------------------|-------------|
| id            | UUID         | PK, auto-gen             | |
| employee_id   | UUID         | FK → employees.id        | |
| school_id     | UUID         | FK → schools.id          | Denormalized for faster queries |
| date          | DATE         | NOT NULL                 | The attendance date |
| status        | VARCHAR(20)  | NOT NULL, CHECK in list  | present / absent / late / excused / remote |
| notes         | TEXT         |                          | Optional manager notes |
| marked_by     | UUID         | FK → users.id            | Who marked it |
| created_at    | TIMESTAMP    | DEFAULT NOW()            | |
| updated_at    | TIMESTAMP    | DEFAULT NOW()            | |

### Unique Constraint
- `UNIQUE(employee_id, date)` — One attendance record per employee per day

### Status Enum
```sql
CHECK (status IN ('present', 'absent', 'late', 'excused', 'remote'))
```

---

## Table: users (Auth)

| Column        | Type         | Constraints    | Description |
|---------------|--------------|----------------|-------------|
| id            | UUID         | PK, auto-gen   | |
| email         | VARCHAR(255) | UNIQUE, NOT NULL | |
| password_hash | VARCHAR(255) | NOT NULL       | |
| role          | VARCHAR(20)  | NOT NULL       | super_admin / school_manager / viewer |
| school_ids    | UUID[]       |                | Array of school IDs (for school_manager) |
| created_at    | TIMESTAMP    | DEFAULT NOW()  | |

---

## Table: schools (Seed Data)

15 schools with the following roster sizes:

```json
[
  { "name": "Riverside Elementary",    "code": "RIV", "roster_size": 12 },
  { "name": "Oak Ridge Middle School", "code": "OAK", "roster_size": 18 },
  { "name": "Summit High School",      "code": "SUM", "roster_size": 24 },
  { "name": "Lincoln Academy",         "code": "LIN", "roster_size": 10 },
  { "name": "Parkside Elementary",     "code": "PRK", "roster_size": 14 },
  { "name": "Westbrook Middle School",  "code": "WBR", "roster_size": 20 },
  { "name": "Eastgate High School",     "code": "EGA", "roster_size": 22 },
  { "name": "Cedar Grove Elementary",   "code": "CDG", "roster_size": 8  },
  { "name": "Northwood Academy",        "code": "NWD", "roster_size": 16 },
  { "name": "Maple Street Elementary",  "code": "MAP", "roster_size": 11 },
  { "name": "Harborview Middle School", "code": "HRB", "roster_size": 19 },
  { "name": "Brighton High School",     "code": "BRI", "roster_size": 25 },
  { "name": "Pinecrest Elementary",     "code": "PNC", "roster_size": 9  },
  { "name": "Stonebridge Academy",      "code": "STB", "roster_size": 15 },
  { "name": "Lakeside High School",     "code": "LKU", "roster_size": 21 }
]
```

---

## Indexes

```sql
CREATE INDEX idx_attendance_school_date ON attendance_records(school_id, date);
CREATE INDEX idx_attendance_employee_date ON attendance_records(employee_id, date);
CREATE INDEX idx_attendance_date ON attendance_records(date);
CREATE INDEX idx_employees_school ON employees(school_id);
```

---

## Sample Master Report Query

```sql
SELECT
  s.name AS school_name,
  COUNT(DISTINCT e.id) AS total_employees,
  COUNT(ar.id) AS total_records,
  SUM(CASE WHEN ar.status = 'present' THEN 1 ELSE 0 END) AS present_count,
  SUM(CASE WHEN ar.status = 'absent'  THEN 1 ELSE 0 END) AS absent_count,
  SUM(CASE WHEN ar.status = 'late'    THEN 1 ELSE 0 END) AS late_count,
  SUM(CASE WHEN ar.status = 'excused' THEN 1 ELSE 0 END) AS excused_count,
  SUM(CASE WHEN ar.status = 'remote'  THEN 1 ELSE 0 END) AS remote_count
FROM schools s
LEFT JOIN employees e ON e.school_id = s.id
LEFT JOIN attendance_records ar ON ar.employee_id = e.id
  AND ar.date BETWEEN :start_date AND :end_date
GROUP BY s.id, s.name
ORDER BY s.name;
```
