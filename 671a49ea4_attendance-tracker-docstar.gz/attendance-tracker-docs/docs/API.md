# API Reference

Base URL: `http://localhost:3000/api`

All endpoints except `/auth/login` require a valid JWT in the `Authorization: Bearer <token>` header.

---

## Auth

### POST /auth/login
```json
// Request
{ "email": "admin@district.edu", "password": "..." }

// Response 200
{ "token": "eyJhbG...", "user": { "id": "...", "role": "super_admin", "school_ids": [] } }
```

---

## Schools

### GET /schools
Returns all 15 schools.
```json
// Response 200
[
  { "id": "uuid", "name": "Riverside Elementary", "code": "RIV", "location": "Riverside, CA" }
]
```

### GET /schools/:id
Returns a single school with its roster.
```json
// Response 200
{
  "id": "uuid",
  "name": "Riverside Elementary",
  "code": "RIV",
  "employees": [
    { "id": "uuid", "first_name": "Jane", "last_name": "Doe", "role": "Teacher", "is_active": true }
  ]
}
```

### POST /schools *(super_admin only)*
```json
{ "name": "New School", "code": "NEW", "location": "City, ST" }
```

---

## Employees

### GET /schools/:schoolId/employees
Returns the roster for a school.

### POST /schools/:schoolId/employees *(super_admin or school_manager)*
```json
{ "first_name": "John", "last_name": "Smith", "role": "Teacher", "email": "john@school.edu" }
```

### PUT /employees/:id *(super_admin or school_manager)*
```json
{ "role": "Vice Principal", "is_active": false }
```

---

## Attendance

### GET /attendance?school_id=uuid&date=2026-08-16
Returns attendance records for a school on a specific date.
```json
// Response 200
[
  {
    "id": "uuid",
    "employee_id": "uuid",
    "employee_name": "Jane Doe",
    "date": "2026-08-16",
    "status": "present",
    "notes": ""
  }
]
```

### GET /attendance?school_id=uuid&start_date=2026-08-01&end_date=2026-08-31
Returns attendance records for a date range (used for the grid view).

### POST /attendance *(super_admin or school_manager)*
Mark or update attendance for an employee on a date.
```json
// Request
{
  "employee_id": "uuid",
  "date": "2026-08-16",
  "status": "present",
  "notes": "Arrived on time"
}

// Response 201
{ "id": "uuid", "employee_id": "uuid", "date": "2026-08-16", "status": "present", "notes": "Arrived on time" }
```

### POST /attendance/bulk *(super_admin or school_manager)*
Batch mark attendance for multiple employees on the same date.
```json
// Request
{
  "school_id": "uuid",
  "date": "2026-08-16",
  "records": [
    { "employee_id": "uuid1", "status": "present" },
    { "employee_id": "uuid2", "status": "absent", "notes": "Sick" },
    { "employee_id": "uuid3", "status": "late" }
  ]
}

// Response 201
{ "created": 3, "updated": 0 }
```

---

## Master Report

### GET /reports/master?start_date=2026-08-01&end_date=2026-08-31
Aggregated attendance across all 15 schools for a date range.
```json
// Response 200
{
  "date_range": { "start": "2026-08-01", "end": "2026-08-31" },
  "schools": [
    {
      "school_id": "uuid",
      "school_name": "Riverside Elementary",
      "total_employees": 12,
      "total_records": 240,
      "present_count": 200,
      "absent_count": 15,
      "late_count": 10,
      "excused_count": 8,
      "remote_count": 7,
      "present_rate": 0.833
    }
  ],
  "totals": {
    "total_employees": 254,
    "total_records": 5080,
    "present_count": 4200,
    "absent_count": 320,
    "late_count": 280,
    "excused_count": 150,
    "remote_count": 130,
    "present_rate": 0.827
  }
}
```

---

## Status Codes

| Code | Meaning |
|------|---------|
| 200  | Success |
| 201  | Created |
| 400  | Bad request |
| 401  | Unauthorized |
| 403  | Forbidden (wrong role/school) |
| 404  | Not found |
| 500  | Server error |
