# School Attendance Tracker

A full-stack attendance tracking system for 15 schools with varying roster sizes. Managers mark employee attendance day-by-day (no clock-in/out). All school data feeds into a single master report.

---

## Overview

- **15 schools**, each with its own roster of employees (varying sizes)
- Managers mark daily attendance: **Present**, **Absent**, **Late**, **Excused**, **Remote**
- One master report aggregates all schools into a single dashboard
- No time-tracking or clock-in/out — just daily status marking

---

## Tech Stack

| Layer       | Technology                  |
|-------------|-----------------------------|
| Frontend    | React + Tailwind CSS        |
| Backend     | Node.js / Express (or Base44 backend functions) |
| Database    | PostgreSQL (or Base44 entities) |
| Auth        | JWT-based, role-based access |

---

## Project Structure

```
attendance-tracker/
├── README.md
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DATA_MODEL.md
│   └── API.md
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── SchoolView.jsx
│   │   │   └── MasterReport.jsx
│   │   ├── components/
│   │   │   ├── AttendanceGrid.jsx
│   │   │   ├── SchoolSelector.jsx
│   │   │   ├── StatusBadge.jsx
│   │   │   └── ReportTable.jsx
│   │   ├── api/
│   │   │   └── client.js
│   │   └── App.jsx
│   └── package.json
├── backend/
│   ├── src/
│   │   ├── routes/
│   │   │   ├── schools.js
│   │   │   ├── employees.js
│   │   │   └── attendance.js
│   │   ├── models/
│   │   │   ├── School.js
│   │   │   ├── Employee.js
│   │   │   └── AttendanceRecord.js
│   │   ├── controllers/
│   │   │   ├── schoolsController.js
│   │   │   ├── employeesController.js
│   │   │   └── attendanceController.js
│   │   └── server.js
│   └── package.json
└── docker-compose.yml
```

---

## Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL 14+ (or a Base44 account)
- Git

### 1. Clone the repo
```bash
git clone https://github.com/your-org/attendance-tracker.git
cd attendance-tracker
```

### 2. Backend setup
```bash
cd backend
npm install
cp .env.example .env  # Set DB connection string, JWT secret
npx knex migrate:latest
npm run dev
```

### 3. Frontend setup
```bash
cd frontend
npm install
npm run dev
```

### 4. Seed demo data
```bash
cd backend
npm run seed  # Creates 15 schools with rosters + sample attendance
```

---

## Roles & Permissions

| Role       | Access |
|------------|--------|
| **Super Admin** | Full access — all schools, master report, manage schools & employees |
| **School Manager** | Mark attendance only for their assigned school(s) |
| **Viewer** | Read-only access to master report |

---

## Attendance Statuses

| Status     | Color     | Description |
|------------|-----------|-------------|
| Present    | Green     | Employee was present for the full day |
| Absent     | Red       | Employee did not show up |
| Late       | Amber     | Arrived late but completed the day |
| Excused    | Blue      | Pre-approved absence (sick, vacation, etc.) |
| Remote     | Purple    | Worked remotely |

---

## The 15 Schools (Demo Data)

| #  | School Name              | Roster Size |
|----|-------------------------|------------|
| 1  | Riverside Elementary     | 12 |
| 2  | Oak Ridge Middle School  | 18 |
| 3  | Summit High School      | 24 |
| 4  | Lincoln Academy          | 10 |
| 5  | Parkside Elementary      | 14 |
| 6  | Westbrook Middle School  | 20 |
| 7  | Eastgate High School     | 22 |
| 8  | Cedar Grove Elementary   | 8  |
| 9  | Northwood Academy        | 16 |
| 10 | Maple Street Elementary  | 11 |
| 11 | Harborview Middle School | 19 |
| 12 | Brighton High School     | 25 |
| 13 | Pinecrest Elementary     | 9  |
| 14 | Stonebridge Academy      | 15 |
| 15 | Lakeside High School     | 21 |

---

## License

MIT
